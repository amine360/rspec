var visitorName = prompt('What is your name?');
console.log(visitorName);