var answer = prompt('What programming language is the name of a gem?');
if ( answer.toUpperCase() === 'RUBY' ) {
  document.write("<p>That's right!</p>");
} else {
  document.write("<p>Sorry, that's wrong.</p>");
} 