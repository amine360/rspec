var alertRandom = function () {
    var randomNumber = Math.floor(Math.random() * 6 ) + 1;
    alert(randomNumber);
};
alertRandom();