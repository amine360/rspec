alert(hello there");
document.rite("No it works!");
